<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="iso graphics" tilewidth="111" tileheight="128" tilecount="55" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_01.png"/>
 </tile>
 <tile id="1">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_02.png"/>
 </tile>
 <tile id="2">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_03.png"/>
 </tile>
 <tile id="3">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_04.png"/>
 </tile>
 <tile id="4">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_05.png"/>
 </tile>
 <tile id="5">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_06.png"/>
 </tile>
 <tile id="6">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_07.png"/>
 </tile>
 <tile id="7">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_08.png"/>
 </tile>
 <tile id="8">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_09.png"/>
 </tile>
 <tile id="9">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_10.png"/>
 </tile>
 <tile id="10">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_11.png"/>
 </tile>
 <tile id="11">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_12.png"/>
 </tile>
 <tile id="12">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_13.png"/>
 </tile>
 <tile id="13">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_14.png"/>
 </tile>
 <tile id="14">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_15.png"/>
 </tile>
 <tile id="15">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_16.png"/>
 </tile>
 <tile id="16">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_17.png"/>
 </tile>
 <tile id="17">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_18.png"/>
 </tile>
 <tile id="18">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_19.png"/>
 </tile>
 <tile id="19">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_20.png"/>
 </tile>
 <tile id="20">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_21.png"/>
 </tile>
 <tile id="21">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_22.png"/>
 </tile>
 <tile id="22">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_23.png"/>
 </tile>
 <tile id="23">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_24.png"/>
 </tile>
 <tile id="24">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_25.png"/>
 </tile>
 <tile id="25">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_26.png"/>
 </tile>
 <tile id="26">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_27.png"/>
 </tile>
 <tile id="27">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_28.png"/>
 </tile>
 <tile id="28">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_29.png"/>
 </tile>
 <tile id="29">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_30.png"/>
 </tile>
 <tile id="30">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_31.png"/>
 </tile>
 <tile id="31">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_32.png"/>
 </tile>
 <tile id="32">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_33.png"/>
 </tile>
 <tile id="33">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_34.png"/>
 </tile>
 <tile id="34">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_35.png"/>
 </tile>
 <tile id="35">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_36.png"/>
 </tile>
 <tile id="36">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_37.png"/>
 </tile>
 <tile id="37">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_38.png"/>
 </tile>
 <tile id="38">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_39.png"/>
 </tile>
 <tile id="39">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_40.png"/>
 </tile>
 <tile id="40">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_41.png"/>
 </tile>
 <tile id="41">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_42.png"/>
 </tile>
 <tile id="42">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_43.png"/>
 </tile>
 <tile id="43">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_44.png"/>
 </tile>
 <tile id="44">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_45.png"/>
 </tile>
 <tile id="45">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_46.png"/>
 </tile>
 <tile id="46">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_47.png"/>
 </tile>
 <tile id="47">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_48.png"/>
 </tile>
 <tile id="48">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_49.png"/>
 </tile>
 <tile id="49">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_50.png"/>
 </tile>
 <tile id="50">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_51.png"/>
 </tile>
 <tile id="51">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_52.png"/>
 </tile>
 <tile id="52">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_53.png"/>
 </tile>
 <tile id="53">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_54.png"/>
 </tile>
 <tile id="54">
  <image width="111" height="128" source="../../graphics/isometric/voxelTile_55.png"/>
 </tile>
</tileset>
